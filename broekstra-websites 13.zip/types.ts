
export interface Project {
  id: string;
  title: string;
  category: string;
  description: string;
  challenge: string;
  solution: string;
  result: string;
  image: string;
}

export interface Service {
  id: string;
  title: string;
  icon: string;
  description: string;
  longDescription: string;
  forWho: string;
  benefits: string[];
  price?: string;
  originalPrice?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  content: string;
  company: string;
}