
import React from 'react';
import { Monitor, RefreshCw, MessageSquare, Compass, Rocket, Palette, Globe, Shield, Zap, Search, Layout } from 'lucide-react';
import { Project, Service, Testimonial } from './types';

export interface ExtendedService extends Service {
  longFeatures: string[];
  process: { title: string; description: string }[];
  targetAudienceDetail: string;
  image: string;
}

export const getServices = (lang: 'nl' = 'nl'): ExtendedService[] => [
  {
    id: 'maatwerk',
    title: 'Webdesign op maat',
    icon: 'Monitor',
    description: 'Een volledig nieuw, uniek ontwerp dat uw merk vanaf de grond opbouwt.',
    longDescription: 'Wij creëren een digitaal visitekaartje dat precies uitstraalt wie u bent. Geen dertien-in-een-dozijn templates, maar puur vakmanschap.',
    forWho: 'Ondernemers die een sterke, nieuwe start willen maken.',
    targetAudienceDetail: 'Dit pakket is ideaal voor de ambitieuze ondernemer die begrijpt dat een eerste indruk goud waard is.',
    benefits: ['Uniek Design', 'Mobile Friendly', 'SEO Basis', 'Direct Online'],
    price: '395',
    originalPrice: '495',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=1200',
    longFeatures: [
      'Volledig uniek responsive design',
      'Tot 5 pagina\'s',
      'Basis SEO optimalisatie',
      'Integratie social media',
      'Beveiligd SSL-certificaat',
      'Gebruiksvriendelijk beheersysteem',
      'AI-verbeterde teksten'
    ],
    process: [
      { title: 'Strategie & Intake', description: 'We bepalen de kernboodschap.' },
      { title: 'Visueel Ontwerp', description: 'Uniek ontwerp op maat.' },
      { title: 'Bouw & Optimalisatie', description: 'Focus op snelheid.' },
      { title: 'Lancering', description: 'De site gaat live.' }
    ]
  },
  {
    id: 'redesign',
    title: 'Website Redesign',
    icon: 'RefreshCw',
    description: 'Uw huidige website in een modern jasje.',
    longDescription: 'Is uw website verouderd of traag? Wij transformeren uw huidige content naar een moderne, luxe ervaring die wél resultaat boekt.',
    forWho: 'Bedrijven toe aan een professionele inhaalslag.',
    targetAudienceDetail: 'Heeft u al een website, maar voelt deze als een blok aan uw been? Wij blazen uw online aanwezigheid nieuw leven in.',
    benefits: ['Moderne Look', 'Betere Conversie', 'Snelle Laadtijd', 'Zorgeloze Migratie'],
    price: '229',
    originalPrice: '375',
    image: 'https://images.unsplash.com/photo-1551434678-e076c223a692?auto=format&fit=crop&q=80&w=1200',
    longFeatures: [
      'Volledige visuele make-over',
      'Behoud van content met AI-verbeteringen',
      'Optimalisatie van laadtijden',
      'Nieuw mobiel menu',
      'Krachtige Call-to-Actions',
      'Opschonen plug-ins',
      'Link check'
    ],
    process: [
      { title: 'Audit huidige site', description: 'Wat kan beter?' },
      { title: 'Migratie', description: 'Overzetten content.' },
      { title: 'Nieuw Jasje', description: 'Modernisering.' },
      { title: 'Livegang', description: 'Upload naar de server.' }
    ]
  },
  {
    id: 'custom',
    title: 'Custom Solution',
    icon: 'Layout',
    description: 'Voor complexe aanvragen en unieke functionaliteiten.',
    longDescription: 'Heeft u specifieke wensen die buiten de standaard pakketten vallen? Wij bouwen oplossingen die exact aansluiten bij uw complexe business logica.',
    forWho: 'Grotere organisaties of ondernemers met unieke wensen.',
    targetAudienceDetail: 'Of het nu gaat om een uitgebreid boekingssysteem, een ledenportaal of een zeer uitgebreide site: wij maken het mogelijk.',
    benefits: ['Onbeperkte Pagina\'s', 'Geavanceerde Functies', 'VIP Support', 'Maatwerk Logica'],
    price: '—',
    image: 'https://images.unsplash.com/photo-1507413245164-6160d8298b31?auto=format&fit=crop&q=80&w=1200',
    longFeatures: [
      'Onbeperkt aantal pagina\'s',
      'Custom API koppelingen',
      'Geavanceerde database structuren',
      'Exclusief design traject',
      'Performance hosting advies',
      'Maandelijkse optimalisatie ronde',
      'Dedicated project manager'
    ],
    process: [
      { title: 'Diepgaande Analyse', description: 'Functioneel ontwerp maken.' },
      { title: 'Prototyping', description: 'Interactief model bouwen.' },
      { title: 'Development', description: 'Maatwerk codering.' },
      { title: 'Testing & Launch', description: 'Extreem testen voor livegang.' }
    ]
  }
];

export const getSteps = (lang: 'nl' = 'nl') => [
  {
    title: 'Kennismaking',
    description: 'We bespreken uw wensen en doelen.',
    icon: <MessageSquare className="w-6 h-6" />,
    image: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&q=80&w=1200'
  },
  {
    title: 'Ontwerp',
    description: 'Wij maken een uniek design dat luxe uitstraalt.',
    icon: <Palette className="w-6 h-6" />,
    image: 'https://images.unsplash.com/photo-1633167606207-d840b5070fc2?auto=format&fit=crop&q=80&w=1200'
  },
  {
    title: 'De Realisatie',
    description: 'Wij bouwen uw site met de modernste technieken.',
    icon: <Globe className="w-6 h-6" />,
    image: 'https://images.unsplash.com/photo-1639322537228-f710d846310a?auto=format&fit=crop&q=80&w=1200'
  },
  {
    title: 'Groei',
    description: 'Uw site is live! Wij blijven bereikbaar.',
    icon: <Rocket className="w-6 h-6" />,
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1200'
  }
];

export const PROJECTS: Project[] = [];

export const TESTIMONIALS: Testimonial[] = [];

export const SERVICES = getServices('nl');
export const STEPS = getSteps('nl');
