
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { LanguageProvider } from './context/LanguageContext.tsx';
import { DynamicDataProvider } from './context/DynamicDataContext.tsx';
import Layout from './components/Layout.tsx';
import Home from './pages/Home.tsx';
import Services from './pages/Services.tsx';
import ServiceDetail from './pages/ServiceDetail.tsx';
import Projects from './pages/Projects.tsx';
import Workflow from './pages/Workflow.tsx';
import About from './pages/About.tsx';
import Contact from './pages/Contact.tsx';
import Privacy from './pages/Privacy.tsx';
import Terms from './pages/Terms.tsx';
import Admin from './pages/Admin.tsx';

const App: React.FC = () => {
  return (
    <LanguageProvider>
      <DynamicDataProvider>
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/diensten" element={<Services />} />
            <Route path="/diensten/:id" element={<ServiceDetail />} />
            <Route path="/projecten" element={<Projects />} />
            <Route path="/werkwijze" element={<Workflow />} />
            <Route path="/over" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/voorwaarden" element={<Terms />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Layout>
      </DynamicDataProvider>
    </LanguageProvider>
  );
};

export default App;
