import React from 'react';

interface LogoProps {
  className?: string;
  variant?: 'dark' | 'light';
  align?: 'center' | 'left';
}

const Logo: React.FC<LogoProps> = ({ className = "", variant = 'dark', align = 'center' }) => {
  const textColor = variant === 'light' ? 'text-white' : 'text-primary';
  const strokeColor = variant === 'light' ? '#FFFFFF' : '#121C26';
  const alignmentClass = align === 'left' ? 'items-start text-left' : 'items-center text-center';

  return (
    <div className={`flex flex-col ${alignmentClass} ${className}`}>
      <div className="relative w-12 h-12 mb-2">
        <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
          <rect x="25" y="30" width="50" height="55" rx="2" stroke={strokeColor} strokeWidth="3" />
          <line x1="25" y1="42" x2="75" y2="42" stroke={strokeColor} strokeWidth="3" />
          <circle cx="68" cy="36" r="2.5" fill="#B3945C" />
          <path d="M40 48V78M40 48C48 48 55 48 58 50C62 52 64 56 64 60C64 64 60 67 55 68C62 69 66 72 66 77C66 82 62 85 55 86C50 87 40 87 40 87" stroke={strokeColor} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
      <div className="flex flex-col items-center">
        <div className={`font-serif text-xl font-bold tracking-[0.1em] ${textColor} leading-none uppercase`}>BROEKSTRA</div>
        <div className="text-[8px] font-black tracking-[0.4em] text-accent mt-1 uppercase">WEBSITES</div>
      </div>
    </div>
  );
};

export default Logo;