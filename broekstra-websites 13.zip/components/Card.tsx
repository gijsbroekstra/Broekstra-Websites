import React from 'react';
import { ArrowUpRight, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface CardProps {
  title: string;
  description: string;
  category?: string;
  image?: string;
  icon?: React.ReactNode;
  link?: string;
  variant?: 'service' | 'project';
}

const Card: React.FC<CardProps> = ({ title, description, category, image, icon, link, variant = 'service' }) => {
  if (variant === 'project') {
    return (
      <div className="group relative overflow-hidden rounded-[2.5rem] bg-white shadow-premium hover:shadow-premium-hover transition-all duration-700 h-full flex flex-col border border-gray-100/50">
        <div className="aspect-[4/3] overflow-hidden relative">
          <img 
            src={image} 
            alt={title} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" 
          />
          <div className="absolute inset-0 bg-primary/10 opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
        </div>
        <div className="p-10 relative z-10 flex-grow flex flex-col">
          <span className="text-[10px] font-black uppercase tracking-[0.4em] text-accent mb-4 block opacity-80">{category}</span>
          <h3 className="text-3xl font-serif font-bold text-primary mb-4 leading-tight italic">{title}</h3>
          <p className="text-gray-500 text-lg mb-10 line-clamp-2 leading-relaxed flex-grow font-medium">{description}</p>
          {link && (
            <div className="mt-auto">
              <Link to={link} className="flex items-center gap-3 text-primary font-black text-[10px] tracking-[0.3em] uppercase transition-all duration-300 hover:text-accent group/link">
                Details bekijken <ArrowUpRight className="w-4 h-4 text-accent group-hover/link:translate-x-1 group-hover/link:-translate-y-1 transition-transform" />
              </Link>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="relative p-12 rounded-[3rem] bg-white border border-gray-100/50 shadow-premium hover:shadow-premium-hover hover:border-accent/20 transition-all duration-700 group h-full flex flex-col overflow-hidden">
      {/* Subtle background glow */}
      <div className="absolute -top-24 -right-24 w-48 h-48 bg-accent/5 rounded-full blur-3xl group-hover:bg-accent/10 transition-colors"></div>
      
      <div className="relative z-10 flex-grow flex flex-col">
        <div className="w-20 h-20 bg-sand rounded-3xl flex items-center justify-center text-primary mb-10 group-hover:bg-accent group-hover:text-sand transition-all duration-700 shadow-[inset_0_2px_4px_rgba(0,0,0,0.02)] shrink-0">
          {icon}
        </div>
        <h3 className="text-3xl font-serif font-bold text-primary mb-6 italic leading-tight">{title}</h3>
        <p className="text-gray-500 text-lg leading-relaxed mb-10 flex-grow font-medium opacity-90">
          {description}
        </p>
        {link && (
          <div className="mt-auto pt-4">
            <Link to={link} className="inline-flex items-center gap-3 text-primary font-black text-[10px] tracking-[0.3em] uppercase transition-all duration-300 hover:text-accent group/link">
              Ontdek meer <ArrowRight size={18} className="text-accent group-hover/link:translate-x-2 transition-transform" />
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default Card;