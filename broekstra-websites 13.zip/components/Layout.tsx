import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, MessageCircle, Mail, Phone, MapPin } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import Logo from './Logo';

interface LayoutProps { children: React.ReactNode; }

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [showSplash, setShowSplash] = useState(true);
  const { t } = useLanguage();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll, { passive: true });
    const timer = setTimeout(() => setShowSplash(false), 2000);
    return () => {
      window.removeEventListener('scroll', handleScroll);
      clearTimeout(timer);
    };
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [location]);

  const navLinks = [
    { name: t('nav.home'), path: '/' },
    { name: t('nav.packages'), path: '/diensten' },
    { name: t('nav.workflow'), path: '/werkwijze' },
    { name: t('nav.about'), path: '/over' },
    { name: t('nav.contact'), path: '/contact' },
  ];

  const isHome = location.pathname === '/' || location.pathname === '';
  const isDarkHeroPage = isHome || location.pathname === '/diensten' || location.pathname === '/over';
  
  const useWhiteText = isScrolled || (isDarkHeroPage && !isScrolled);

  return (
    <div className={`min-h-screen flex flex-col selection:bg-accent selection:text-white ${showSplash ? 'overflow-hidden max-h-screen' : ''} bg-sand`}>
      
      {showSplash && (
        <div className="splash-screen splash-exit" style={{ zIndex: 9999 }}>
          <div className="flex flex-col items-center">
             <Logo variant="light" className="scale-150 mb-12" />
             <div className="w-16 h-0.5 bg-accent/20 rounded-full overflow-hidden">
                <div className="w-full h-full bg-accent animate-[curtainRight_2s_ease-in-out_infinite]"></div>
             </div>
          </div>
        </div>
      )}

      {/* Floating WhatsApp */}
      <a 
        href="https://wa.me/31636071498" 
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-10 right-10 z-[100] bg-[#25D366] text-white p-5 rounded-full shadow-[0_20px_40px_rgba(37,211,102,0.3)] hover:scale-110 transition-transform flex items-center justify-center group"
      >
        <MessageCircle size={26} />
        <span className="max-w-0 overflow-hidden whitespace-nowrap group-hover:max-w-xs group-hover:ml-3 transition-all duration-700 font-black uppercase tracking-[0.3em] text-[9px]">
           Direct Appen
        </span>
      </a>

      <header className={`fixed top-0 left-0 right-0 z-[500] transition-all duration-700 ${isScrolled ? 'header-visible py-4' : 'py-12'}`}>
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center relative z-[510]">
          <Link to="/" className={`transition-all duration-700 origin-left block pointer-events-auto ${isScrolled ? 'scale-[0.85]' : 'scale-100'}`}>
            <Logo variant={useWhiteText ? 'light' : 'dark'} align="left" />
          </Link>

          <nav className="hidden lg:flex items-center gap-12 pointer-events-auto">
            {navLinks.map((link) => (
              <Link 
                key={link.path} 
                to={link.path} 
                className={`text-[10px] font-black uppercase tracking-[0.4em] transition-all duration-500 hover:opacity-100 ${
                  location.pathname === link.path 
                    ? 'text-accent' 
                    : (useWhiteText ? 'text-white/70 hover:text-white' : 'text-primary/70 hover:text-primary')
                }`}
              >
                {link.name}
              </Link>
            ))}
            
            <Link to="/contact" className="glisten-btn bg-accent text-primary px-10 py-3.5 rounded-full text-[10px] font-black tracking-[0.2em] uppercase hover:bg-white transition-all shadow-premium inline-flex items-center justify-center text-center">
              {t('nav.cta')}
            </Link>
          </nav>

          <button className={`lg:hidden p-2 transition-transform hover:scale-110 relative z-[520] pointer-events-auto ${useWhiteText ? 'text-white' : 'text-primary'}`} onClick={() => setIsMenuOpen(true)}>
            <Menu size={28} />
          </button>
        </div>

        {/* Mobile Menu */}
        <div className={`lg:hidden fixed inset-0 bg-primary z-[600] flex flex-col items-center justify-center gap-10 transition-all duration-700 ${isMenuOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-full pointer-events-none'}`}>
          <button className="absolute top-12 right-8 text-white hover:rotate-90 transition-transform duration-500" onClick={() => setIsMenuOpen(false)}>
            <X size={36} />
          </button>
          {navLinks.map((link) => (
            <Link key={link.path} to={link.path} onClick={() => setIsMenuOpen(false)} className={`text-4xl font-serif font-black italic tracking-tight transition-all hover:text-accent ${location.pathname === link.path ? 'text-accent' : 'text-white'}`}>
              {link.name}
            </Link>
          ))}
          <Link to="/contact" onClick={() => setIsMenuOpen(false)} className="bg-accent text-primary px-12 py-5 rounded-full font-black tracking-[0.2em] uppercase text-xs mt-6 shadow-premium flex items-center justify-center">
            {t('nav.cta')}
          </Link>
        </div>
      </header>

      <main className="flex-grow">
        {children}
      </main>

      <footer className="bg-primary text-white py-32 px-6 overflow-hidden border-t border-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-start gap-20 mb-32">
            <div className="space-y-8 max-w-md">
              <Logo variant="light" align="left" className="scale-110 origin-left" />
              <p className="text-2xl font-serif font-bold text-accent italic tracking-tight leading-snug opacity-90">
                "{t('hero.subtitle')}"
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-16 md:gap-24 text-sm">
               <div className="space-y-6">
                  <div className="flex items-center gap-5 text-accent group cursor-default">
                    <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center transition-colors group-hover:bg-accent/20">
                      <MapPin size={18} />
                    </div>
                    <span className="text-white font-black tracking-[0.3em] uppercase text-[10px] opacity-70">Apeldoorn, NL</span>
                  </div>
                  <a href="mailto:info@broekstrawebsites.nl" className="flex items-center gap-5 text-accent group">
                    <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center transition-colors group-hover:bg-accent/20">
                      <Mail size={18} />
                    </div>
                    <span className="text-white font-black tracking-[0.3em] uppercase text-[10px] opacity-70 transition-opacity group-hover:opacity-100">info@broekstrawebsites.nl</span>
                  </a>
               </div>
               <div className="space-y-6">
                  <a href="tel:+31636071498" className="flex items-center gap-5 text-accent group">
                    <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center transition-colors group-hover:bg-accent/20">
                      <Phone size={18} />
                    </div>
                    <span className="text-white font-black tracking-[0.3em] uppercase text-[10px] opacity-70 transition-opacity group-hover:opacity-100">+31 6 36071498</span>
                  </a>
                  <a href="https://wa.me/31636071498" className="flex items-center gap-5 text-accent group">
                    <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center transition-colors group-hover:bg-accent/20">
                      <MessageCircle size={18} />
                    </div>
                    <span className="text-white font-black tracking-[0.3em] uppercase text-[10px] opacity-70 transition-opacity group-hover:opacity-100">WhatsApp Direct</span>
                  </a>
               </div>
            </div>
          </div>
          <div className="pt-16 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-10 text-[9px] text-gray-500 font-black tracking-[0.4em] uppercase">
            <p>&copy; {new Date().getFullYear()} Broekstra Websites | All Rights Reserved</p>
            <div className="flex gap-12">
              <Link to="/privacy" className="hover:text-accent transition-colors">Privacy</Link>
              <Link to="/voorwaarden" className="hover:text-accent transition-colors">Voorwaarden</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
