
import React, { createContext, useContext, useState, useEffect } from 'react';
import { getServices, ExtendedService } from '../constants';

interface DynamicDataContextType {
  services: ExtendedService[];
  updateService: (updatedService: ExtendedService) => void;
  resetToDefault: () => void;
}

const DynamicDataContext = createContext<DynamicDataContextType | undefined>(undefined);

export const DynamicDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [services, setServices] = useState<ExtendedService[]>([]);

  useEffect(() => {
    const savedServices = localStorage.getItem('broekstra_services');
    if (savedServices) {
      setServices(JSON.parse(savedServices));
    } else {
      setServices(getServices('nl'));
    }
  }, []);

  const updateService = (updatedService: ExtendedService) => {
    const newServices = services.map(s => s.id === updatedService.id ? updatedService : s);
    setServices(newServices);
    localStorage.setItem('broekstra_services', JSON.stringify(newServices));
  };

  const resetToDefault = () => {
    const defaults = getServices('nl');
    setServices(defaults);
    localStorage.removeItem('broekstra_services');
  };

  return (
    <DynamicDataContext.Provider value={{ services, updateService, resetToDefault }}>
      {children}
    </DynamicDataContext.Provider>
  );
};

export const useDynamicData = () => {
  const context = useContext(DynamicDataContext);
  if (!context) throw new Error('useDynamicData must be used within DynamicDataProvider');
  return context;
};
