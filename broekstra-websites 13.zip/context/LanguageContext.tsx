
import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'nl';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const translations: Record<Language, Record<string, string>> = {
  nl: {
    'nav.home': 'Home',
    'nav.packages': 'Pakketten',
    'nav.workflow': 'Werkwijze',
    'nav.about': 'Over Broekstra Websites',
    'nav.contact': 'Contact',
    'nav.cta': 'Gratis intake',
    'hero.badge': 'Website Bouwer & AI Expert',
    'hero.title': 'Krachtige websites.',
    'hero.title.accent': 'Slim gebouwd.',
    'hero.subtitle': '"Voor ondernemers die meer willen!"',
    'hero.desc': 'Broekstra Websites transformeert uw visie naar een luxe digitale ervaring. Vaste prijzen, geen verrassingen.',
    'hero.price.custom': 'Maatwerk',
    'hero.price.redesign': 'Redesign',
    'hero.price.excl': 'Excl. BTW',
    'hero.cta.start': 'Start Uw Project',
    'hero.cta.packages': 'Onze Pakketten',
    'footer.privacy': 'Privacy',
    'footer.terms': 'Voorwaarden',
    'services.title': 'Onze Pakketten',
    'services.subtitle': 'Transparant ontwerp.',
    'services.subtitle.accent': 'Direct Online.',
    'services.included': 'Inbegrepen:',
    'services.view': 'Dit pakket bekijken',
    'services.ask': 'Stel een vraag',
    'services.hosting.info': 'Broekstra Websites doet niet aan eigen hosting, maar wij nemen u volledig mee in het proces en adviseren u over de beste partij.',
    'services.hosting.strato': 'Wij begeleiden de volledige technische inrichting bij een hostingpartij naar keuze.',
    'services.hosting.detail': 'U blijft zelf eigenaar van uw hostingpakket en domeinnaam, terwijl wij zorgen dat alles technisch perfect staat ingesteld.',
    'services.support.title': 'Altijd paraat',
    'services.support.desc': 'Heeft u na de livegang nog hulp nodig of wilt u iets kleins veranderen? Wij staan altijd klaar.',
    'services.support.cta': 'Ontdek onze werkwijze',
    'services.cta.title': 'Vragen over hosting?',
    'services.cta.desc': 'Wij adviseren u graag over welke partij het beste bij uw groeiambities past.',
    'services.cta.contact': 'Direct Contact',
    'services.cta.call': 'Bel me even',
    'detail.back': 'Terug naar pakketten',
    'detail.price': 'Pakketprijs',
    'detail.apply': 'Dit pakket aanvragen',
    'detail.what': 'Wat u precies krijgt',
    'detail.what.desc': 'Bij Broekstra Websites gaan we verder dan alleen een mooi plaatje.',
    'detail.for': 'Voor wie is dit?',
    'detail.process': 'Het Proces',
    'detail.trust': 'Geen zorgen',
    'detail.trust.desc': 'Wij leveren pas op als u 100% tevreden bent.',
    'detail.ready': 'Klaar om te starten?',
    'detail.ready.desc': 'Laten we samen kijken hoe we uw project tot een succes maken.',
    'detail.ready.cta': 'Plan intake in',
    'detail.whatsapp': 'WhatsApp ons',
    'workflow.badge': 'Stap voor stap',
    'workflow.title': 'Onze Werkwijze',
    'workflow.desc': 'Wij geloven in transparantie en rust. Geen technische overload, maar een helder proces.',
    'workflow.impact': 'Resultaat telt',
    'workflow.impact.title': 'Direct impact,',
    'workflow.impact.accent': 'geen gedoe.',
    'workflow.impact.desc': 'Onze missie is simpel: u een website bezorgen die staat als een huis.',
    'about.title': 'Over Broekstra Websites',
    'about.intro': 'Broekstra Websites is een modern webdesign & AI-gedreven bureau.',
    'about.desc': 'Wij bouwen websites die vertrouwen uitstralen en converteren. Onze focus ligt op rust, overzicht en een persoonlijke aanpak.',
    'about.identity.badge': 'Onze Identiteit',
    'about.identity.title': 'Gedreven door passie',
    'about.identity.desc': 'Broekstra Websites is ontstaan vanuit een liefde voor minimalistisch design en krachtige techniek.',
    'about.cta.meet': 'Laten we kennismaken',
    'about.cta.call': 'Bel direct',
    'about.cta.ready': 'Klaar voor de volgende stap?',
    'contact.title': 'Laten we praten.',
    'contact.subtitle': 'Heeft u een vraag, wilt u een offerte of wilt u gewoon even sparren?',
    'contact.info': 'Contactgegevens',
    'contact.whatsapp.cta': 'WhatsApp Direct',
    'contact.form.name': 'Naam',
    'contact.form.email': 'Email',
    'contact.form.phone': 'Telefoon',
    'contact.form.subject': 'Onderwerp',
    'contact.form.message': 'Bericht',
    'contact.form.placeholder.name': 'Uw naam',
    'contact.form.placeholder.email': 'Uw emailadres',
    'contact.form.placeholder.message': 'Vertel ons kort wat uw wensen zijn...',
    'contact.form.send': 'Verstuur aanvraag',
    'contact.form.sending': 'Bezig met verzenden...',
    'contact.form.success.title': 'Bericht verzonden!',
    'contact.form.success.desc': 'Bedankt voor uw interesse. Wij nemen binnen 24 uur contact met u op.',
    'contact.form.success.again': 'Nog een bericht sturen?',
    'contact.form.error': 'Er is iets misgegaan. Mail ons direct.',
    'contact.form.options.new': 'Nieuwe website',
    'contact.form.options.redesign': 'Redesign van website',
    'contact.form.options.hosting': 'Vraag over hosting',
    'contact.form.options.other': 'Anders'
  }
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language] = useState<Language>('nl');

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  const t = (key: string) => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: () => {}, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useLanguage must be used within LanguageProvider');
  return context;
};
