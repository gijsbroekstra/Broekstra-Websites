# Broekstra Websites - Premium Web Agency

Dit is de broncode voor de officiële website van Broekstra Websites. Een modern, conversiegericht platform gebouwd met React, Vite en Tailwind CSS.

## Kenmerken
- **Premium Design**: Focus op luxe typografie en witruimte.
- **Conversiegericht**: Geoptimaliseerde Call-to-Actions en zwevende contactmogelijkheden.
- **Meertalig**: Volledige ondersteuning voor Nederlands en Engels.
- **Performance**: Razendsnelle laadtijden door Vite en moderne asset-optimalisatie.

## Ontwikkeling
1. Installeer afhankelijkheden: `npm install`
2. Start development server: `npm run dev`
3. Bouw voor productie: `npm run build`

## Structuur
- `src/pages`: Alle paginacontent (Home, Diensten, Portfolio, Contact).
- `src/components`: Herbruikbare UI elementen (Logo, Layout, Cards).
- `src/constants.tsx`: De "bron van waarheid" voor alle teksten, projecten en diensten.

---
*Gemaakt voor Broekstra Websites - "Voor ondernemers die meer willen!"*
