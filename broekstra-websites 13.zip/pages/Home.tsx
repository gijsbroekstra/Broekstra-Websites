
import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, PhoneCall, Zap, Search, Palette, Rocket, Globe, Shield, Smartphone, Layout as IconLayout, Sparkles as SparklesIcon } from 'lucide-react';
import Card from '../components/Card';
import { useDynamicData } from '../context/DynamicDataContext';
import { useLanguage } from '../context/LanguageContext';
import * as Icons from 'lucide-react';

const USPS_DATA = [
  { title: 'Snelle Schakels', subtitle: 'Direct contact', icon: <Zap size={22} />, bg: 'bg-white', color: 'text-accent' },
  { title: 'Luxe Design', subtitle: 'Exclusief gevoel', icon: <Palette size={22} />, bg: 'bg-primary', color: 'text-accent' },
  { title: 'Hosting Begeleiding', subtitle: 'Technisch advies', icon: <Globe size={22} />, bg: 'bg-white', color: 'text-accent' },
  { title: 'SEO Focus', subtitle: 'Word gevonden', icon: <Search size={22} />, bg: 'bg-primary', color: 'text-accent' },
  { title: 'Conversie Boost', subtitle: 'Meer klanten', icon: <Rocket size={22} />, bg: 'bg-white', color: 'text-accent' },
  { title: 'Mobile First', subtitle: 'Overal perfect', icon: <Smartphone size={22} />, bg: 'bg-primary', color: 'text-accent' },
  { title: 'SSL Veilig', subtitle: 'Privacy gewaarborgd', icon: <Shield size={22} />, bg: 'bg-white', color: 'text-accent' },
  { title: 'AI Teksten', subtitle: 'Slimme copy', icon: <IconLayout size={22} />, bg: 'bg-primary', color: 'text-accent' },
];

interface USPItemProps {
  item: typeof USPS_DATA[0];
}

const USPItem: React.FC<USPItemProps> = ({ item }) => (
  <div className={`${item.bg} p-10 rounded-[3rem] border ${item.bg === 'bg-primary' ? 'border-white/5 shadow-2xl' : 'border-gray-50 shadow-premium'} text-center group h-64 flex flex-col justify-center transition-all duration-700 hover:scale-[1.02] shrink-0`}>
    <div className={`w-14 h-14 ${item.bg === 'bg-primary' ? 'bg-white/5' : 'bg-sand'} rounded-2xl flex items-center justify-center ${item.color} mx-auto mb-6 shadow-inner group-hover:scale-110 transition-all duration-700`}>
      {item.icon}
    </div>
    <h3 className={`text-xl font-serif font-black mb-1 italic tracking-tight ${item.bg === 'bg-primary' ? 'text-accent' : 'text-primary'}`}>{item.title}</h3>
    <div className={`text-[9px] font-black uppercase tracking-[0.4em] opacity-60 ${item.bg === 'bg-primary' ? 'text-white' : 'text-gray-400'}`}>{item.subtitle}</div>
  </div>
);

const Home: React.FC = () => {
  const { t } = useLanguage();
  const { services } = useDynamicData();
  const revealRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1 }
    );
    revealRefs.current.forEach((ref) => { if (ref) observer.observe(ref); });
    return () => observer.disconnect();
  }, []);

  const addToRefs = (el: HTMLDivElement | null) => {
    if (el && !revealRefs.current.includes(el)) revealRefs.current.push(el);
  };

  return (
    <div className="space-y-0 bg-sand">
      {/* Hero Section */}
      <section className="relative h-screen min-h-[750px] flex items-center bg-primary overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1614850523296-d8c1af93d400?auto=format&fit=crop&q=80&w=2000')] bg-cover bg-center opacity-[0.25] scale-105 animate-[pulse_20s_infinite]"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-primary via-primary/80 to-primary"></div>
        </div>

        <div className="max-w-7xl mx-auto px-6 relative z-10 w-full pt-12 text-center lg:text-left">
          <div className="flex flex-col items-center lg:items-start animate-in fade-in slide-in-from-bottom duration-1000">
            <div className="inline-flex items-center gap-3 bg-white/5 backdrop-blur-md px-5 py-2.5 rounded-full border border-white/10 mb-8">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-accent"></span>
              </span>
              <span className="text-[9px] font-black text-white tracking-[0.5em] uppercase opacity-90">{t('hero.badge')}</span>
            </div>
            
            <h1 className="text-6xl md:text-8xl lg:text-[7.5rem] font-serif font-extrabold text-white leading-[0.9] mb-8 tracking-tighter">
              {t('hero.title')} <br />
              <span className="text-accent italic">{t('hero.title.accent')}</span>
            </h1>

            <div className="max-w-2xl border-l-[3px] border-accent/40 lg:pl-8 md:pl-10 py-1 mb-12 lg:mx-0 mx-auto">
              <p className="text-xl md:text-2xl font-serif font-bold text-gray-300 italic tracking-tight leading-snug">
                {t('hero.subtitle')}
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-6 items-center w-full sm:w-auto">
              <Link to="/contact" className="glisten-btn group bg-accent text-primary px-12 py-6 rounded-full font-black tracking-[0.2em] uppercase text-[10px] inline-flex items-center justify-center gap-4 hover:bg-white transition-all shadow-gold-glow w-full sm:w-auto">
                <span>{t('hero.cta.start')}</span>
                <ArrowRight size={18} className="group-hover:translate-x-1.5 transition-transform" />
              </Link>
              <Link to="/diensten" className="glisten-btn group border border-white/20 text-white px-12 py-6 rounded-full font-black tracking-[0.2em] uppercase text-[10px] inline-flex items-center justify-center gap-4 hover:bg-white/5 transition-all w-full sm:w-auto text-center leading-none">
                <span>{t('hero.cta.packages')}</span>
              </Link>
            </div>
          </div>
        </div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4 text-white/20">
          <span className="text-[8px] font-black uppercase tracking-[0.6em] rotate-90 mb-8">Scroll</span>
          <div className="w-px h-16 bg-gradient-to-b from-accent/50 to-transparent"></div>
        </div>
      </section>

      {/* Expertise Section */}
      <section className="bg-white py-32 md:py-48 reveal overflow-hidden" ref={addToRefs}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-12 gap-20 items-center">
            <div className="lg:col-span-5 space-y-12">
              <div className="space-y-6">
                <div className="inline-flex items-center gap-3 bg-accent/5 px-4 py-2 rounded-full border border-accent/10 mb-2">
                  <span className="text-accent font-black uppercase tracking-[0.4em] text-[10px]">Luxe Webdesign & SEO</span>
                </div>
                <h2 className="text-6xl md:text-7xl lg:text-[8rem] font-serif font-extrabold text-primary leading-[0.85] tracking-tighter italic">
                  Onze <br />
                  <span className="text-accent">Expertise.</span>
                </h2>
              </div>
              
              <p className="text-xl md:text-2xl text-gray-500 font-bold leading-relaxed border-l-[3px] border-accent pl-8 italic opacity-90">
                Wij bouwen websites die niet alleen prachtig zijn, maar ook werken. Van professionele hosting begeleiding tot geavanceerde SEO-optimalisatie; wij regelen alles van A tot Z.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-6 pt-4">
                <Link to="/over" className="glisten-btn group bg-primary text-white px-12 py-6 rounded-full font-black tracking-[0.2em] uppercase text-[10px] inline-flex items-center justify-center gap-4 hover:bg-accent hover:text-primary transition-all shadow-premium w-full sm:w-auto text-center leading-none">
                  <span>Over Broekstra Websites</span>
                  <ArrowRight size={18} className="group-hover:translate-x-1.5 transition-transform" />
                </Link>
              </div>
            </div>

            <div className="lg:col-span-6 lg:col-start-7 h-[800px] overflow-hidden relative marquee-container marquee-mask flex gap-6 md:gap-8">
              <div className="flex-1 flex flex-col gap-6 md:gap-8 marquee-up">
                {[...USPS_DATA, ...USPS_DATA].map((item, i) => (
                  <USPItem key={i} item={item} />
                ))}
              </div>
              <div className="flex-1 flex flex-col gap-6 md:gap-8 marquee-down pt-32">
                {[...USPS_DATA, ...USPS_DATA].reverse().map((item, i) => (
                  <USPItem key={i} item={item} />
                ))}
              </div>
              
              <div className="absolute top-0 left-0 right-0 h-48 bg-gradient-to-b from-white to-transparent z-20"></div>
              <div className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-white to-transparent z-20"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="max-w-7xl mx-auto px-6 py-32 md:py-48 reveal" ref={addToRefs}>
        <div className="flex flex-col md:flex-row justify-between items-end mb-20 md:mb-32 gap-10">
          <div className="max-w-2xl">
            <span className="text-accent font-black uppercase tracking-[0.4em] text-[10px] mb-6 block">Onze Oplossingen</span>
            <h2 className="text-5xl md:text-7xl lg:text-[8rem] font-serif font-extrabold text-primary leading-none tracking-tighter italic">Pakketten & Maatwerk</h2>
          </div>
          <Link to="/diensten" className="group flex items-center gap-4 text-primary font-black uppercase tracking-[0.3em] text-[10px] border-b border-accent/40 pb-2 hover:border-accent transition-colors">
            Alle details bekijken <ArrowRight size={16} className="group-hover:translate-x-2 transition-transform duration-500" />
          </Link>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12 items-stretch">
          {services.map((service) => {
            const IconComponent = (Icons as any)[service.icon];
            const isCustom = service.id === 'custom' || service.price === '—';
            return (
              <div key={service.id} className="relative group flex flex-col h-full">
                <div className="flex-grow">
                  <Card 
                    title={service.title} 
                    description={service.description} 
                    icon={<IconComponent size={34} />} 
                    link={`/diensten/${service.id}`} 
                    variant="project"
                    image={service.image}
                  />
                </div>
                
                {/* Fixed width for gold price boxes to ensure consistency */}
                <div className="absolute top-8 right-8 md:top-10 md:right-10 flex flex-col items-end z-20 group-hover:-translate-y-2 transition-transform duration-700 pointer-events-none gap-2">
                    {service.originalPrice && (
                      <div className="bg-white px-5 py-2 rounded-full border border-gray-100 shadow-sm flex items-center justify-center min-w-[100px]">
                        <span className="text-gray-400 font-bold line-through text-[11px]">€{service.originalPrice}</span>
                      </div>
                    )}
                    <div className="bg-accent text-primary w-44 h-20 md:w-48 md:h-22 rounded-[2rem] flex flex-col items-center justify-center shadow-gold-glow border border-white/10 group-hover:shadow-2xl transition-all duration-700">
                        <span className="font-black tracking-tight text-2xl">
                          € {service.price}
                        </span>
                        {service.price !== '—' ? (
                          <span className="text-[9px] font-black opacity-70 uppercase tracking-widest mt-0.5">Excl. BTW</span>
                        ) : (
                          <span className="text-[9px] font-black opacity-70 uppercase tracking-widest mt-0.5">Prijs op aanvraag</span>
                        )}
                    </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Final Lead Section */}
      <section className="px-6 py-32 md:py-48 reveal" ref={addToRefs}>
        <div className="max-w-6xl mx-auto bg-primary text-white rounded-[4rem] md:rounded-[5rem] p-16 md:p-32 text-center relative overflow-hidden group shadow-premium-hover border border-white/5">
          <div className="absolute inset-0 bg-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-1000"></div>
          
          <h2 className="text-5xl md:text-7xl lg:text-[8rem] font-serif font-extrabold mb-10 relative z-10 leading-[0.9] tracking-tighter italic">Laten we bouwen.</h2>
          <p className="text-xl md:text-2xl text-gray-400 mb-16 max-w-2xl mx-auto font-bold uppercase tracking-tight relative z-10 opacity-80">
            Bent u klaar voor een website die écht voor u werkt?
          </p>
          
          <div className="flex flex-col sm:flex-row gap-8 justify-center relative z-10 items-center">
            <Link 
              to="/contact" 
              className="glisten-btn group bg-accent text-primary px-14 py-7 rounded-full font-black tracking-[0.2em] uppercase text-[10px] inline-flex items-center justify-center gap-4 hover:bg-white transition-all shadow-gold-glow w-full sm:w-auto"
            >
              <span>Gratis Intake Plannen</span>
              <ArrowRight size={20} className="group-hover:translate-x-1.5 transition-transform" />
            </Link>
            <a 
              href="tel:+31636071498" 
              className="glisten-btn group border border-accent/40 text-accent px-14 py-7 rounded-full font-black tracking-[0.2em] uppercase text-[10px] inline-flex items-center gap-5 hover:bg-accent hover:text-primary transition-all w-full sm:w-auto justify-center"
            >
              <PhoneCall size={20} />
              <span>Direct bellen</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
