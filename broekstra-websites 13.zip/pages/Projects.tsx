
import React from 'react';
import { PROJECTS } from '../constants';
import { ArrowRight, Trophy, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

const Projects: React.FC = () => {
  return (
    <div className="pb-32">
      <section className="bg-primary text-white py-48 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary via-primary/80 to-primary"></div>
        <div className="max-w-7xl mx-auto relative z-10">
          <span className="text-accent font-black uppercase tracking-[0.4em] text-[10px] mb-4 block">Portfolio</span>
          <h1 className="text-6xl lg:text-9xl font-serif font-extrabold mb-8 leading-none">Recent Werk</h1>
          <p className="text-2xl text-gray-300 max-w-2xl font-bold italic border-l-4 border-accent pl-8">
            Een selectie van onze projecten waar we trots op zijn. Van minimalistische redesigns tot krachtige bedrijfswebsites.
          </p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 mt-32 space-y-48">
        {PROJECTS.length === 0 ? (
          <div className="bg-white p-20 rounded-[4rem] text-center border border-gray-100 shadow-sm relative overflow-hidden group">
             <div className="absolute inset-0 bg-sand opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
             <h3 className="text-4xl font-serif font-extrabold text-primary mb-6 relative z-10 italic">Momenteel in de steigers...</h3>
             <p className="text-xl text-gray-500 max-w-xl mx-auto relative z-10 font-medium">
               Wij leggen momenteel de laatste hand aan onze eerste exclusieve projecten voor ondernemers. Binnenkort ziet u hier het resultaat.
             </p>
             <div className="mt-12 relative z-10">
               <Link 
                 to="/contact" 
                 className="group relative bg-primary text-white px-10 py-6 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center gap-4 hover:bg-accent transition-all duration-500 shadow-2xl overflow-hidden"
               >
                 <span className="relative z-10">Word ons eerste succesverhaal</span>
                 <ArrowRight size={20} className="group-hover:translate-x-2 transition-transform" />
                 <div className="absolute top-0 -left-full w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent group-hover:left-full transition-all duration-700 ease-in-out"></div>
               </Link>
             </div>
          </div>
        ) : (
          PROJECTS.map((project, idx) => (
            <div key={project.id} className="grid lg:grid-cols-2 gap-20 items-center">
              <div className="space-y-12 order-2 lg:order-1">
                <div>
                  <span className="text-accent font-black uppercase tracking-[0.4em] text-[10px] mb-4 block">{project.category}</span>
                  <h2 className="text-5xl font-serif font-extrabold text-primary mb-8 leading-tight italic">{project.title}</h2>
                  <p className="text-2xl text-gray-600 italic border-l-4 border-accent pl-8 py-2 font-bold leading-relaxed">
                    "{project.description}"
                  </p>
                </div>

                <div className="grid sm:grid-cols-2 gap-10">
                  <div className="space-y-4">
                    <h4 className="font-black text-primary uppercase tracking-widest text-xs">De Uitdaging</h4>
                    <p className="text-gray-500 font-medium leading-relaxed">{project.challenge}</p>
                  </div>
                  <div className="space-y-4">
                    <h4 className="font-black text-primary uppercase tracking-widest text-xs">De Oplossing</h4>
                    <p className="text-gray-500 font-medium leading-relaxed">{project.solution}</p>
                  </div>
                </div>

                <div className="bg-sand p-10 rounded-[3rem] flex items-center gap-8 border border-gray-100 shadow-inner">
                  <div className="w-16 h-16 bg-accent text-white rounded-2xl flex items-center justify-center shrink-0 shadow-lg">
                    <Trophy size={32} />
                  </div>
                  <div>
                    <h4 className="font-black text-primary uppercase tracking-widest text-xs mb-1">Het Resultaat</h4>
                    <p className="text-xl text-primary font-extrabold italic">{project.result}</p>
                  </div>
                </div>

                <div className="pt-4">
                  <Link 
                    to="/contact" 
                    className="group relative bg-primary text-white px-10 py-6 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center gap-4 hover:bg-accent transition-all duration-500 shadow-2xl overflow-hidden"
                  >
                    <span className="relative z-10">Ook zo'n website?</span>
                    <ArrowRight size={20} className="group-hover:translate-x-2 transition-transform" />
                    <div className="absolute top-0 -left-full w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent group-hover:left-full transition-all duration-700 ease-in-out"></div>
                  </Link>
                </div>
              </div>

              <div className="order-1 lg:order-2 rounded-[4rem] overflow-hidden shadow-[0_50px_100px_rgba(0,0,0,0.1)] border-8 border-white group">
                <img src={project.image} alt={project.title} className="w-full h-auto hover:scale-105 transition-transform duration-[2000ms]" />
              </div>
            </div>
          ))
        )}
      </section>

      {/* Enhanced Bottom CTA Section */}
      <section className="mt-48 px-6 text-center">
        <div className="max-w-5xl mx-auto space-y-12 bg-primary p-16 md:p-28 rounded-[4rem] text-white relative overflow-hidden group">
          <div className="absolute inset-0 bg-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-accent/10 blur-[120px] rounded-full translate-x-1/2 -translate-y-1/2"></div>
          
          <h2 className="text-5xl lg:text-8xl font-serif font-extrabold relative z-10 leading-none">Nieuwe website?</h2>
          <p className="text-2xl text-gray-300 font-black max-w-2xl mx-auto relative z-10 uppercase tracking-tight">
            Wij helpen u graag bij het realiseren van een website die écht voor u werkt.
          </p>
          
          <div className="pt-10 flex flex-col sm:flex-row justify-center gap-8 relative z-10 items-center">
            <Link 
              to="/contact" 
              className="group relative bg-white text-primary px-12 py-6 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center gap-4 hover:bg-accent hover:text-white transition-all duration-500 shadow-[0_20px_40px_rgba(0,0,0,0.4)] hover:-translate-y-2 overflow-hidden"
            >
              <span className="relative z-10">Plan gratis intake</span>
              <ArrowRight size={22} className="relative z-10 group-hover:translate-x-2 transition-transform duration-500" />
              <div className="absolute top-0 -left-full w-full h-full bg-gradient-to-r from-transparent via-primary/20 to-transparent group-hover:left-full transition-all duration-700 ease-in-out"></div>
            </Link>
            
            <Link 
              to="/diensten" 
              className="group border-2 border-white text-white px-12 py-6 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center gap-4 hover:bg-white hover:text-primary transition-all duration-500 shadow-xl hover:-translate-y-2"
            >
              <Sparkles size={22} className="group-hover:rotate-12 transition-transform duration-500" />
              <span>Bekijk pakketten</span>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Projects;
