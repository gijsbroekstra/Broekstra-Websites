
import React, { useState } from 'react';
import { Mail, Phone, MapPin, MessageCircle, Send, CheckCircle, AlertCircle } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

const Contact: React.FC = () => {
  const [formState, setFormState] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const { t, language } = useLanguage();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormState('submitting');
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    try {
      const response = await fetch('https://formspree.io/f/xovjqqov', {
        method: 'POST',
        body: formData,
        headers: { 'Accept': 'application/json' }
      });
      if (response.ok) {
        setFormState('success');
        form.reset();
      } else {
        throw new Error('Submission failed');
      }
    } catch (error) {
      setFormState('error');
    }
  };

  return (
    <div className="pb-32">
      <section className="bg-sand py-12 lg:py-16 px-6 pt-28 lg:pt-48">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-5xl lg:text-7xl font-serif font-extrabold text-primary mb-6 leading-tight italic">{t('contact.title')}</h1>
          <p className="text-xl text-gray-600 max-w-2xl font-bold italic border-l-4 border-accent pl-6">
            {t('contact.subtitle')}
          </p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 mt-12 lg:mt-16">
        <div className="grid lg:grid-cols-5 gap-12 lg:gap-16">
          <div className="lg:col-span-2 space-y-10">
            <div>
              <h3 className="text-2xl font-serif font-bold text-primary mb-6 italic">{t('contact.info')}</h3>
              <div className="space-y-6">
                <a href="mailto:info@broekstrawebsites.nl" className="flex items-center gap-6 group">
                  <div className="w-12 h-12 bg-white rounded-2xl shadow-sm border border-gray-100 flex items-center justify-center text-accent group-hover:bg-accent group-hover:text-white transition-all">
                    <Mail size={24} />
                  </div>
                  <div>
                    <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('contact.form.email')}</div>
                    <div className="text-lg font-bold text-primary">info@broekstrawebsites.nl</div>
                  </div>
                </a>
                <a href="tel:+31636071498" className="flex items-center gap-6 group">
                  <div className="w-12 h-12 bg-white rounded-2xl shadow-sm border border-gray-100 flex items-center justify-center text-accent group-hover:bg-accent group-hover:text-white transition-all">
                    <Phone size={24} />
                  </div>
                  <div>
                    <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('contact.form.phone')}</div>
                    <div className="text-lg font-bold text-primary">+31 (0)6 36071498</div>
                  </div>
                </a>
                <div className="flex items-center gap-6">
                  <div className="w-12 h-12 bg-white rounded-2xl shadow-sm border border-gray-100 flex items-center justify-center text-accent">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Location</div>
                    <div className="text-lg font-bold text-primary">{language === 'nl' ? 'Regio Apeldoorn, NL' : 'Apeldoorn Region, NL'}</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-primary p-10 rounded-3xl text-white shadow-2xl relative overflow-hidden group">
              <h4 className="text-xl font-bold mb-4 font-serif italic text-accent">{language === 'nl' ? 'Meteen antwoord?' : 'Quick answer?'}</h4>
              <p className="text-gray-300 mb-8 font-medium">{language === 'nl' ? 'Stuur een WhatsApp voor een snelle reactie.' : 'Send a WhatsApp for a quick response.'}</p>
              <a href="https://wa.me/31636071498" target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-3 bg-[#25D366] text-white py-4 rounded-full font-black tracking-widest uppercase text-xs hover:opacity-90 transition-opacity shadow-lg">
                <MessageCircle size={24} />
                {t('contact.whatsapp.cta')}
              </a>
            </div>
          </div>

          <div className="lg:col-span-3">
            <div className="bg-white p-10 lg:p-16 rounded-[3rem] shadow-xl border border-gray-100">
              {formState === 'success' ? (
                <div className="text-center py-10 space-y-6">
                  <CheckCircle size={40} className="text-green-600 mx-auto" />
                  <h3 className="text-3xl font-extrabold text-primary font-serif italic">{t('contact.form.success.title')}</h3>
                  <p className="text-gray-600 font-bold">{t('contact.form.success.desc')}</p>
                  <button onClick={() => setFormState('idle')} className="text-accent font-black tracking-widest uppercase text-xs border-b border-accent">
                    {t('contact.form.success.again')}
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-8">
                  <div className="grid md:grid-cols-2 gap-8">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-primary uppercase tracking-[0.3em]">{t('contact.form.name')}</label>
                      <input type="text" name="name" required placeholder={t('contact.form.placeholder.name')} className="w-full bg-sand border border-gray-100 rounded-2xl px-6 py-4 outline-none focus:border-accent font-medium text-primary" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-primary uppercase tracking-[0.3em]">{t('contact.form.email')}</label>
                      <input type="email" name="email" required placeholder={t('contact.form.placeholder.email')} className="w-full bg-sand border border-gray-100 rounded-2xl px-6 py-4 outline-none focus:border-accent font-medium text-primary" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-primary uppercase tracking-[0.3em]">{t('contact.form.subject')}</label>
                    <select name="category" className="w-full bg-sand border border-gray-100 rounded-2xl px-6 py-4 outline-none focus:border-accent font-bold appearance-none text-primary">
                      <option>{t('contact.form.options.new')}</option>
                      <option>{t('contact.form.options.redesign')}</option>
                      <option>{t('contact.form.options.hosting')}</option>
                      <option>{t('contact.form.options.other')}</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-primary uppercase tracking-[0.3em]">{t('contact.form.message')}</label>
                    <textarea name="message" rows={5} required placeholder={t('contact.form.placeholder.message')} className="w-full bg-sand border border-gray-100 rounded-2xl px-6 py-4 outline-none focus:border-accent resize-none font-medium text-primary"></textarea>
                  </div>
                  {formState === 'error' && <div className="text-red-600 flex items-center gap-3"><AlertCircle /> {t('contact.form.error')}</div>}
                  {/* GOUD BUTTON (Verstuur) */}
                  <button type="submit" disabled={formState === 'submitting'} className="glisten-btn group relative bg-accent text-primary w-full py-6 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center justify-center gap-4 hover:bg-primary hover:text-white transition-all duration-500 shadow-xl disabled:opacity-70">
                    <span className="relative z-10">{formState === 'submitting' ? t('contact.form.sending') : t('contact.form.send')}</span>
                    <Send size={20} className="relative z-10 group-hover:translate-x-2 transition-transform" />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
