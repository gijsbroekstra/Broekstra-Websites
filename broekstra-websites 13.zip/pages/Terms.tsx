
import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const Terms: React.FC = () => {
  const { language, t } = useLanguage();

  if (language === 'en') {
    return (
      <div className="pb-32 pt-40 lg:pt-56 px-6">
        <div className="max-w-4xl mx-auto bg-white p-10 md:p-16 rounded-[3rem] shadow-sm border border-gray-100 space-y-20">
          <section>
            <h1 className="text-4xl lg:text-5xl font-serif font-extrabold text-primary mb-12 italic">2. Terms & Conditions</h1>
            <div className="space-y-10 text-gray-600 font-medium leading-relaxed">
              <section className="space-y-2">
                <h2 className="text-xl font-serif font-bold text-primary">2.1 Applicability</h2>
                <p>These general terms and conditions apply to all quotes, agreements, and activities of Broekstra Websites.</p>
              </section>
              <section className="space-y-2">
                <h2 className="text-xl font-serif font-bold text-primary">2.2 Formation of Agreement</h2>
                <p>An agreement is formed after written or digital approval from the client.</p>
              </section>
              <section className="space-y-2">
                <h2 className="text-xl font-serif font-bold text-primary">2.3 Execution</h2>
                <p>Broekstra Websites carries out activities to the best of its knowledge and ability.</p>
              </section>
              <section className="space-y-2">
                <h2 className="text-xl font-serif font-bold text-primary">2.4 Client Cooperation</h2>
                <p>The client ensures timely delivery of all necessary information and materials.</p>
              </section>
              <section className="space-y-2">
                <h2 className="text-xl font-serif font-bold text-primary">2.5 Payment</h2>
                <p>Payment must be made within 14 days of the invoice date.</p>
              </section>
              <section className="space-y-2">
                <h2 className="text-xl font-serif font-bold text-primary">2.6 Intellectual Property</h2>
                <p>All intellectual property rights remain with Broekstra Websites until full payment has been received.</p>
              </section>
            </div>
          </section>

          <section className="pt-12 border-t border-gray-100">
            <h2 className="text-3xl font-serif font-extrabold text-primary mb-8 italic">3. Data Processing (GDPR)</h2>
            <p className="text-gray-600 font-medium">Broekstra Websites processes data only on behalf of the client and takes appropriate security measures in accordance with GDPR regulations.</p>
          </section>

          <div className="pt-12 text-center">
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em]">Broekstra Websites • Last updated: {new Date().toLocaleDateString('en-GB')}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-32 pt-40 lg:pt-56 px-6">
      <div className="max-w-4xl mx-auto bg-white p-10 md:p-16 rounded-[3rem] shadow-sm border border-gray-100 space-y-20">
        
        {/* Sectie 2: Algemene Voorwaarden */}
        <section>
          <h1 className="text-4xl lg:text-5xl font-serif font-extrabold text-primary mb-12 italic">2. Algemene Voorwaarden</h1>
          <div className="space-y-10 text-gray-600 font-medium leading-relaxed">
            
            <section className="space-y-2">
              <h2 className="text-xl font-serif font-bold text-primary">2.1 Toepasselijkheid</h2>
              <p>Deze algemene voorwaarden zijn van toepassing op alle offertes, overeenkomsten en werkzaamheden van Broekstra Websites.</p>
            </section>

            <section className="space-y-2">
              <h2 className="text-xl font-serif font-bold text-primary">2.2 Totstandkoming overeenkomst</h2>
              <p>Een overeenkomst komt tot stand na schriftelijk of digitaal akkoord van opdrachtgever.</p>
            </section>

            <section className="space-y-2">
              <h2 className="text-xl font-serif font-bold text-primary">2.3 Uitvoering van de overeenkomst</h2>
              <p>Broekstra Websites voert de werkzaamheden uit naar beste inzicht en vermogen, conform artikel 7:401 BW.</p>
            </section>

            <section className="space-y-2">
              <h2 className="text-xl font-serif font-bold text-primary">2.4 Medewerking opdrachtgever</h2>
              <p>Opdrachtgever draagt zorg voor tijdige aanlevering van alle benodigde informatie en materialen.</p>
            </section>

            <section className="space-y-2">
              <h2 className="text-xl font-serif font-bold text-primary">2.5 Wijzigingen en correcties</h2>
              <p>Één correctieronde is inbegrepen. Extra wijzigingen worden tegen meerprijs uitgevoerd.</p>
            </section>

            <section className="space-y-2">
              <h2 className="text-xl font-serif font-bold text-primary">2.6 Oplevering</h2>
              <p>De website wordt als opgeleverd beschouwd op het moment van livegang of overdracht.</p>
            </section>

            <section className="space-y-2">
              <h2 className="text-xl font-serif font-bold text-primary">2.7 Betaling</h2>
              <p>Betaling dient te geschieden binnen 14 dagen na factuurdatum.</p>
            </section>

            <section className="space-y-2">
              <h2 className="text-xl font-serif font-bold text-primary">2.8 Aansprakelijkheid</h2>
              <p>Aansprakelijkheid is beperkt tot het factuurbedrag van de betreffende opdracht.</p>
            </section>

            <section className="space-y-2">
              <h2 className="text-xl font-serif font-bold text-primary">2.10 Intellectueel eigendom</h2>
              <p>Alle intellectuele eigendomsrechten blijven bij Broekstra Websites totdat volledige betaling heeft plaatsgevonden.</p>
            </section>
          </div>
        </section>

        {/* Sectie 3: Verwerkersovereenkomst */}
        <section className="pt-12 border-t border-gray-100">
          <h2 className="text-3xl font-serif font-extrabold text-primary mb-8 italic">3. Verwerkersovereenkomst (AVG)</h2>
          <div className="space-y-6 text-gray-600 font-medium">
            <p>Indien Broekstra Websites in opdracht van opdrachtgever persoonsgegevens verwerkt, handelt Broekstra Websites als verwerker in de zin van artikel 4 AVG.</p>
          </div>
        </section>

        <div className="pt-12 text-center">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em]">Broekstra Websites • Laatst bijgewerkt: {new Date().toLocaleDateString('nl-NL')}</p>
        </div>
      </div>
    </div>
  );
};

export default Terms;
