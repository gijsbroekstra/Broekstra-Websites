
import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const Privacy: React.FC = () => {
  const { language } = useLanguage();

  if (language === 'en') {
    return (
      <div className="pb-32 pt-40 lg:pt-56 px-6">
        <div className="max-w-4xl mx-auto bg-white p-10 md:p-16 rounded-[3rem] shadow-sm border border-gray-100">
          <h1 className="text-4xl lg:text-5xl font-serif font-extrabold text-primary mb-12 italic">1. Privacy Statement (GDPR)</h1>
          <div className="space-y-12 text-gray-600 font-medium leading-relaxed">
            <p>Broekstra Websites processes personal data in accordance with the General Data Protection Regulation (GDPR / Regulation (EU) 2016/679).</p>
            <section className="space-y-4">
              <h2 className="text-2xl font-serif font-bold text-primary italic">1.1 Processed Data</h2>
              <p>We only process data provided actively by customers, including: Name, Email, Phone, IP-address, and login details where necessary.</p>
            </section>
            <section className="space-y-4">
              <h2 className="text-2xl font-serif font-bold text-primary italic">1.2 Purposes</h2>
              <p>Data is processed solely for executing agreements, communication, administration, and legal compliance.</p>
            </section>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-32 pt-40 lg:pt-56 px-6">
      <div className="max-w-4xl mx-auto bg-white p-10 md:p-16 rounded-[3rem] shadow-sm border border-gray-100">
        <h1 className="text-4xl lg:text-5xl font-serif font-extrabold text-primary mb-12 italic">1. Privacyverklaring (AVG)</h1>
        <div className="space-y-12 text-gray-600 font-medium leading-relaxed">
          <p className="text-lg">Broekstra Websites verwerkt persoonsgegevens conform de Algemene Verordening Gegevensbescherming (AVG).</p>
          <section className="space-y-4">
            <h2 className="text-2xl font-serif font-bold text-primary italic underline decoration-accent/30 decoration-2 underline-offset-8">1.1 Verwerkte persoonsgegevens</h2>
            <p>Wij verwerken uitsluitend persoonsgegevens die door klanten of bezoekers actief worden verstrekt.</p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Privacy;
