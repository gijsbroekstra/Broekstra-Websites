
import React from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { useDynamicData } from '../context/DynamicDataContext';
import { useLanguage } from '../context/LanguageContext';
import * as Icons from 'lucide-react';
import { ArrowRight, CheckCircle2, ShieldCheck, ArrowLeft, MessageSquare } from 'lucide-react';

const ServiceDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useLanguage();
  const { services } = useDynamicData();
  const service = services.find((s) => s.id === id);

  if (!service) {
    return <Navigate to="/diensten" replace />;
  }

  const IconComponent = (Icons as any)[service.icon];
  const isCustom = service.id === 'custom' || service.price === '—';

  return (
    <div className="pb-32">
      {/* Hero Header */}
      <section className="bg-primary text-white pt-48 pb-32 px-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-accent/5 blur-[120px] rounded-full translate-x-1/2 -translate-y-1/2 animate-pulse"></div>
        <div className="max-w-7xl mx-auto relative z-10">
          <Link to="/diensten" className="inline-flex items-center gap-2 text-accent font-black uppercase tracking-widest text-[10px] mb-12 hover:translate-x-[-8px] transition-transform">
            <ArrowLeft size={16} /> {t('detail.back')}
          </Link>
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-12">
            <div className="max-w-3xl space-y-8">
              <div className="w-20 h-20 bg-accent text-primary rounded-[2rem] flex items-center justify-center shadow-2xl">
                <IconComponent size={36} />
              </div>
              <h1 className="text-6xl lg:text-9xl font-serif font-extrabold leading-none">{service.title}</h1>
              <p className="text-2xl text-gray-300 font-bold italic border-l-4 border-accent pl-8">
                {service.description}
              </p>
            </div>
            {/* Price Card */}
            <div className="bg-accent p-8 md:p-12 rounded-[3.5rem] shadow-[0_40px_80px_rgba(179,148,92,0.3)] w-full lg:w-[400px] border border-white/20 relative group">
              <div className="flex flex-col mb-10">
                <span className="text-primary font-black uppercase tracking-[0.4em] text-[10px] mb-4 block opacity-60">
                   Pakketprijs
                </span>
                
                {service.originalPrice && (
                  <span className="text-primary/40 font-black line-through text-2xl mb-1">€{service.originalPrice}</span>
                )}
                
                <div className="flex items-baseline gap-2 text-primary">
                  <div className="font-serif font-black text-6xl">
                    € {service.price}
                  </div>
                </div>
                <span className="text-primary font-bold uppercase tracking-widest text-[10px] mt-1 opacity-70">
                   {isCustom ? 'Prijs op aanvraag' : t('hero.price.excl')}
                </span>
              </div>
              
              <Link 
                to="/contact" 
                className="group relative bg-primary text-white w-full py-5 rounded-full font-black tracking-[0.15em] uppercase text-[9px] md:text-xs inline-flex items-center justify-center gap-3 hover:bg-white hover:text-primary transition-all duration-500 shadow-2xl overflow-hidden"
              >
                <span className="relative z-10 whitespace-nowrap">{isCustom ? 'Aanvraag Starten' : t('detail.apply')}</span>
                <ArrowRight size={18} className="relative z-10 group-hover:translate-x-1.5 transition-transform" />
                <div className="absolute top-0 -left-full w-full h-full bg-gradient-to-r from-transparent via-white/10 to-transparent group-hover:left-full transition-all duration-700 ease-in-out"></div>
              </Link>
              
              {service.originalPrice && (
                <div className="absolute -top-4 -right-4 bg-primary text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-2xl rotate-12">
                   Actieprijs
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="max-w-7xl mx-auto px-6 mt-32">
        <div className="grid lg:grid-cols-12 gap-20">
          <div className="lg:col-span-7 space-y-20">
            <div className="space-y-10">
              <h2 className="text-4xl font-serif font-extrabold text-primary italic">{t('detail.what')}</h2>
              <p className="text-xl text-gray-500 leading-relaxed font-medium">
                {isCustom ? 'Voor de Custom Solution leveren we een volledig op maat gemaakt traject inclusief strategische sessies.' : t('detail.what.desc')}
              </p>
              <div className="grid gap-6">
                {service.longFeatures.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-6 group">
                    <div className="w-12 h-12 bg-sand text-accent rounded-2xl flex items-center justify-center shrink-0 group-hover:bg-accent group-hover:text-white transition-all duration-500">
                      <CheckCircle2 size={24} />
                    </div>
                    <p className="text-lg text-gray-700 font-bold pt-2">{feature}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-sand p-12 md:p-16 rounded-[4rem] border border-gray-100">
               <h3 className="text-3xl font-serif font-extrabold text-primary mb-8 italic">{t('detail.for')}</h3>
               <p className="text-xl text-gray-600 leading-relaxed font-bold border-l-4 border-accent pl-8">
                 {service.targetAudienceDetail}
               </p>
            </div>
          </div>

          <div className="lg:col-span-5">
             <div className="sticky top-32 space-y-12">
                <div className="bg-primary text-white p-12 rounded-[3.5rem] shadow-2xl relative overflow-hidden group">
                   <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700"></div>
                   <h3 className="text-3xl font-serif font-extrabold mb-10 italic">Aanpak</h3>
                   <div className="space-y-12 relative z-10">
                      {service.process.map((p, idx) => (
                        <div key={idx} className="flex gap-8 relative">
                           {idx !== service.process.length - 1 && (
                             <div className="absolute left-6 top-12 bottom-[-48px] w-px bg-white/20"></div>
                           )}
                           <div className="w-12 h-12 bg-accent text-primary rounded-full flex items-center justify-center shrink-0 font-black text-sm border-4 border-primary shadow-xl">
                              {idx + 1}
                           </div>
                           <div className="space-y-2 pt-2">
                              <h4 className="text-xl font-extrabold text-accent uppercase tracking-tight">{p.title}</h4>
                              <p className="text-gray-400 text-sm font-medium leading-relaxed">{p.description}</p>
                           </div>
                        </div>
                      ))}
                   </div>
                </div>

                <div className="bg-white p-10 rounded-[3rem] border border-gray-100 flex items-center gap-8 shadow-sm">
                   <div className="w-16 h-16 bg-sand text-accent rounded-2xl flex items-center justify-center">
                      <ShieldCheck size={32} />
                   </div>
                   <div>
                      <h4 className="font-black text-primary uppercase tracking-widest text-[10px] mb-1">{t('detail.trust')}</h4>
                      <p className="text-sm text-gray-500 font-bold">{t('detail.trust.desc')}</p>
                   </div>
                </div>
             </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="mt-40 px-6">
        <div className="max-w-5xl mx-auto bg-accent p-16 md:p-24 rounded-[4rem] text-center text-primary relative overflow-hidden group">
           <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
           <h2 className="text-5xl lg:text-7xl font-serif font-extrabold mb-10 leading-none italic">{isCustom ? 'Unieke uitdaging?' : t('detail.ready')}</h2>
           <p className="text-2xl font-black max-w-xl mx-auto mb-16 uppercase tracking-tight opacity-80">
              {isCustom ? 'Wij bijten ons graag vast in complexe trajecten. Laten we uw visie werkelijkheid maken.' : t('detail.ready.desc')}
           </p>
           <div className="flex flex-col sm:flex-row gap-8 justify-center items-center relative z-10">
              <Link 
                to="/contact" 
                className="group relative bg-primary text-white px-12 py-6 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center gap-4 hover:bg-white hover:text-primary transition-all duration-500 shadow-2xl hover:-translate-y-1 overflow-hidden"
              >
                <span className="relative z-10">{isCustom ? 'Samen sparren' : t('detail.ready.cta')}</span>
                <ArrowRight size={22} className="relative z-10 group-hover:translate-x-2 transition-transform" />
              </Link>
              <a 
                href="https://wa.me/31636071498" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group border-2 border-primary text-primary px-12 py-6 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center gap-4 hover:bg-primary hover:text-white transition-all duration-500"
              >
                <MessageSquare size={22} className="group-hover:rotate-12 transition-transform" />
                <span>{t('detail.whatsapp')}</span>
              </a>
           </div>
        </div>
      </section>
    </div>
  );
};

export default ServiceDetail;
