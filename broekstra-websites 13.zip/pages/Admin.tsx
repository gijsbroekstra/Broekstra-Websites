
import React, { useState } from 'react';
import { useDynamicData } from '../context/DynamicDataContext';
import { Lock, Save, RefreshCw, Image as ImageIcon, Tag, Type, LogOut, CheckCircle2, Clipboard } from 'lucide-react';

const Admin: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { services, updateService, resetToDefault } = useDynamicData();
  const [successMsg, setSuccessMsg] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'broekstra2025') {
      setIsAuthenticated(true);
      setError('');
    } else {
      setError('Onjuist wachtwoord.');
    }
  };

  const handleUpdate = (id: string, field: string, value: string) => {
    const service = services.find(s => s.id === id);
    if (service) {
      updateService({ ...service, [field]: value });
      setSuccessMsg('Wijziging tijdelijk opgeslagen!');
      setTimeout(() => setSuccessMsg(''), 3000);
    }
  };

  const copyConfig = () => {
    const configString = JSON.stringify(services, null, 2);
    navigator.clipboard.writeText(configString);
    setSuccessMsg('Configuratie gekopieerd naar klembord!');
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-primary flex items-center justify-center px-6">
        <div className="max-w-md w-full bg-white/5 backdrop-blur-xl p-12 rounded-[3rem] border border-white/10 text-center">
          <div className="w-20 h-20 bg-accent rounded-3xl flex items-center justify-center mx-auto mb-10 shadow-gold-glow">
            <Lock size={32} className="text-primary" />
          </div>
          <h1 className="text-3xl font-serif font-black text-white mb-4 italic">Owner Access</h1>
          <p className="text-gray-400 text-sm font-bold uppercase tracking-widest mb-10">Voer uw wachtwoord in</p>
          <form onSubmit={handleLogin} className="space-y-6">
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:border-accent font-bold text-center"
              placeholder="••••••••"
            />
            {error && <p className="text-red-400 text-xs font-black uppercase tracking-widest">{error}</p>}
            <button type="submit" className="w-full bg-accent text-primary py-5 rounded-2xl font-black uppercase tracking-[0.2em] text-xs hover:bg-white transition-all shadow-xl">
              Inloggen
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-primary text-white pt-32 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-8 mb-20">
          <div>
            <div className="inline-flex items-center gap-3 bg-accent/20 px-4 py-2 rounded-full border border-accent/20 mb-6">
              <span className="w-2 h-2 bg-accent rounded-full animate-pulse"></span>
              <span className="text-[10px] font-black uppercase tracking-widest">Control Center</span>
            </div>
            <h1 className="text-6xl md:text-8xl font-serif font-black italic tracking-tighter">Website <span className="text-accent">Editor</span></h1>
          </div>
          <div className="flex gap-4">
            <button onClick={copyConfig} className="bg-white/5 border border-white/10 px-8 py-4 rounded-full text-[10px] font-black uppercase tracking-widest hover:bg-accent hover:text-primary transition-all flex items-center gap-3">
              <Clipboard size={16} /> Export Config
            </button>
            <button onClick={() => setIsAuthenticated(false)} className="bg-red-500/10 border border-red-500/20 text-red-400 px-8 py-4 rounded-full text-[10px] font-black uppercase tracking-widest hover:bg-red-500 hover:text-white transition-all flex items-center gap-3">
              <LogOut size={16} /> Uitloggen
            </button>
          </div>
        </div>

        {successMsg && (
          <div className="fixed top-10 left-1/2 -translate-x-1/2 z-[1000] bg-accent text-primary px-8 py-4 rounded-full font-black uppercase tracking-widest text-xs flex items-center gap-3 shadow-2xl animate-in fade-in slide-in-from-top">
            <CheckCircle2 size={18} /> {successMsg}
          </div>
        )}

        <div className="grid lg:grid-cols-1 gap-12">
          {services.map((service) => (
            <div key={service.id} className="bg-white/5 border border-white/10 rounded-[3rem] p-10 md:p-16 flex flex-col lg:flex-row gap-16 group hover:border-accent/30 transition-all duration-700">
              <div className="lg:w-1/3 space-y-8">
                <div className="aspect-square rounded-[2.5rem] overflow-hidden border-4 border-white/5 relative">
                  <img src={service.image} alt={service.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-primary/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <ImageIcon className="text-accent" size={48} />
                  </div>
                </div>
                <div>
                   <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-3 block">Afbeelding URL</label>
                   <input 
                    type="text" 
                    value={service.image} 
                    onChange={(e) => handleUpdate(service.id, 'image', e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-5 py-3 text-xs text-gray-400 outline-none focus:border-accent"
                   />
                </div>
              </div>

              <div className="lg:w-2/3 grid md:grid-cols-2 gap-10">
                <div className="space-y-8">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-accent uppercase tracking-widest flex items-center gap-2">
                      <Type size={14} /> Pakket Titel
                    </label>
                    <input 
                      type="text" 
                      value={service.title} 
                      onChange={(e) => handleUpdate(service.id, 'title', e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold outline-none focus:border-accent"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-accent uppercase tracking-widest flex items-center gap-2">
                      <Tag size={14} /> Korte Omschrijving
                    </label>
                    <textarea 
                      value={service.description} 
                      onChange={(e) => handleUpdate(service.id, 'description', e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-gray-300 font-medium outline-none focus:border-accent h-32 resize-none"
                    />
                  </div>
                </div>

                <div className="space-y-8">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-accent uppercase tracking-widest">Huidige Prijs</label>
                      <input 
                        type="text" 
                        value={service.price} 
                        onChange={(e) => handleUpdate(service.id, 'price', e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-black text-2xl outline-none focus:border-accent"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Oude Prijs</label>
                      <input 
                        type="text" 
                        value={service.originalPrice || ''} 
                        onChange={(e) => handleUpdate(service.id, 'originalPrice', e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-gray-400 font-bold outline-none focus:border-accent"
                        placeholder="Leeg voor geen korting"
                      />
                    </div>
                  </div>
                  
                  <div className="bg-primary-light p-8 rounded-3xl border border-white/5 space-y-6">
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-accent">Admin Quick Actions</h4>
                    <div className="flex flex-wrap gap-4">
                      <button 
                        onClick={() => handleUpdate(service.id, 'price', '—')}
                        className="bg-white/5 hover:bg-accent hover:text-primary px-4 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all"
                      >
                        Zet op 'Op aanvraag'
                      </button>
                      <button 
                        onClick={() => handleUpdate(service.id, 'originalPrice', '')}
                        className="bg-white/5 hover:bg-red-500/20 hover:text-red-400 px-4 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all"
                      >
                        Verwijder Korting
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-20 pt-20 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-10">
           <p className="text-gray-500 font-bold italic">Wijzigingen zijn direct zichtbaar op de site (voor u).</p>
           <button onClick={resetToDefault} className="flex items-center gap-3 text-red-400 font-black uppercase tracking-widest text-[10px] hover:text-red-300 transition-colors">
             <RefreshCw size={16} /> Reset naar standaard waarden
           </button>
        </div>
      </div>
    </div>
  );
};

export default Admin;
