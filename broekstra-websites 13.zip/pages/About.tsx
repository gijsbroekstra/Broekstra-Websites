
import React from 'react';
import { Award, User, Palette, Sparkles, Code2, Zap, ArrowRight, PhoneCall, Rocket, Compass, Quote } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import Logo from '../components/Logo';

const About: React.FC = () => {
  const { t } = useLanguage();

  const pillars = [
    { 
      title: 'Duidelijke Structuur', 
      icon: <Palette className="w-8 h-8" />,
      desc: 'Een logische opbouw zorgt ervoor dat uw boodschap direct overkomt.'
    },
    { 
      title: 'Persoonlijke Aanpak', 
      icon: <User className="w-8 h-8" />,
      desc: 'Direct contact en korte lijnen. Wij denken mee met uw wensen.'
    },
    { 
      title: 'Kwaliteit voorop', 
      icon: <Award className="w-8 h-8" />,
      desc: 'Hoogwaardige afwerking en een eerlijk tarief voor elke ondernemer.'
    }
  ];

  return (
    <div className="pb-32">
      {/* Hero Header */}
      <section className="bg-primary text-white pt-56 pb-40 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=2000')] bg-cover bg-fixed opacity-15"></div>
        <div className="absolute top-0 right-0 w-1/2 h-full bg-accent/5 blur-[150px] rounded-full translate-x-1/2 -translate-y-1/2"></div>
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="max-w-5xl">
            <span className="text-accent font-black uppercase tracking-[0.4em] text-xs mb-8 block">Onze Missie</span>
            <h1 className="text-6xl lg:text-[10rem] font-serif font-extrabold mb-12 leading-[0.85] tracking-tighter animate-in fade-in slide-in-from-bottom duration-700">Over <span className="text-accent italic">Broekstra Websites</span></h1>
            <div className="space-y-12">
              <p className="text-3xl md:text-5xl text-accent font-serif italic border-l-4 border-accent pl-10 py-2 leading-tight">
                "Wij geloven dat elke ondernemer een luxe digitale aanwezigheid verdient, zonder de technische stress."
              </p>
              <p className="text-xl md:text-2xl text-gray-300 leading-relaxed font-bold max-w-3xl">
                Broekstra Websites is ontstaan vanuit een passie voor design en techniek. Wij combineren vakmanschap met moderne AI-tools om razendsnel websites van topkwaliteit op te leveren.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Vision Statement (Replaces the previous image) */}
      <section className="max-w-7xl mx-auto px-6 -mt-20 relative z-20">
        <div className="bg-white rounded-[4rem] p-16 md:p-32 shadow-premium-hover border border-gray-100 flex flex-col items-center text-center space-y-12">
          <div className="w-20 h-20 bg-sand rounded-full flex items-center justify-center text-accent mb-4">
            <Quote size={40} fill="currentColor" className="opacity-20" />
          </div>
          <h2 className="text-4xl md:text-6xl lg:text-7xl font-serif font-extrabold text-primary leading-tight tracking-tighter italic">
            Focus op wat u <span className="text-accent underline decoration-accent/20 underline-offset-8">echt</span> drijft. <br />
            Wij regelen de techniek.
          </h2>
          <div className="max-w-3xl">
            <p className="text-xl md:text-2xl text-gray-500 font-bold leading-relaxed">
              Uw website is meer dan een online visitekaartje; het is de motor van uw onderneming. Terwijl u zich richt op uw vakmanschap, zorgen wij voor een vlekkeloze, razendsnelle en visueel verbluffende online presentatie. Geen gedoe met hosting, geen zorgen over veiligheid – alleen resultaat.
            </p>
          </div>
          <div className="pt-8">
            <div className="h-1 w-24 bg-accent/20 rounded-full mx-auto"></div>
          </div>
        </div>
      </section>

      {/* Core Pillars */}
      <section className="max-w-7xl mx-auto px-6 py-40">
        <div className="text-center mb-24">
          <h2 className="text-5xl lg:text-7xl font-serif font-extrabold text-primary mb-6">Onze <span className="text-accent italic">Pijlers</span></h2>
          <div className="w-24 h-1 bg-accent mx-auto rounded-full"></div>
        </div>
        <div className="grid md:grid-cols-3 gap-12">
          {pillars.map((val, idx) => (
            <div key={idx} className="p-16 bg-white rounded-[3.5rem] border border-gray-50 shadow-sm text-center space-y-8 hover:shadow-2xl transition-all duration-700 hover:-translate-y-2">
              <div className="w-24 h-24 bg-sand text-accent rounded-3xl flex items-center justify-center mx-auto shadow-inner">
                {val.icon}
              </div>
              <h3 className="text-3xl font-serif font-bold text-primary italic">{val.title}</h3>
              <p className="text-gray-500 font-bold text-lg leading-relaxed">{val.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Monumental Brand Showcase */}
      <section className="bg-primary py-40 px-6 overflow-hidden relative">
        <div className="absolute inset-0 bg-accent/[0.03] animate-pulse"></div>
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-col items-center text-center space-y-20">
            <div className="space-y-6 max-w-4xl">
              <span className="text-accent font-black uppercase tracking-[0.5em] text-xs">De Kern van Ons Merk</span>
              <h2 className="text-6xl md:text-8xl lg:text-[9rem] font-serif font-extrabold text-white leading-none tracking-tighter italic">Vakmanschap in <br /><span className="text-accent">Elk Detail.</span></h2>
            </div>

            <div className="w-full max-w-5xl aspect-video bg-white/5 backdrop-blur-3xl rounded-[4rem] border border-white/10 flex items-center justify-center relative group p-20">
               <div className="absolute inset-0 bg-gradient-to-tr from-accent/10 via-transparent to-primary/30 rounded-[4rem] opacity-0 group-hover:opacity-100 transition-opacity duration-1000"></div>
               
               <div className="transform scale-[3.5] md:scale-[5] transition-transform duration-1000 group-hover:scale-[3.7] md:group-hover:scale-[5.2]">
                  <Logo variant="light" />
               </div>

               <div className="absolute top-12 left-12 w-20 h-20 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-accent animate-bounce">
                  <Sparkles size={32} />
               </div>
               <div className="absolute bottom-12 right-12 w-24 h-24 rounded-full bg-accent/10 border border-accent/20 flex items-center justify-center text-white animate-pulse">
                  <Zap size={40} />
               </div>
            </div>

            <p className="text-2xl md:text-3xl text-gray-400 font-serif italic max-w-3xl leading-relaxed">
              "Wij bouwen niet zomaar websites; wij smeden een digitaal fundament waarop uw onderneming jarenlang kan groeien."
            </p>
            
            <div className="flex flex-col sm:flex-row gap-8 items-center pt-8">
              <Link to="/contact" className="glisten-btn group relative bg-accent text-primary px-14 py-8 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center justify-center gap-4 hover:bg-white transition-all duration-500 shadow-2xl w-full sm:w-auto text-center leading-none">
                <span>Direct aan de slag</span>
                <ArrowRight size={22} className="group-hover:translate-x-2 transition-transform" />
              </Link>
              <a href="tel:+31636071498" className="glisten-btn group border-2 border-accent text-accent px-14 py-8 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center justify-center gap-4 hover:bg-accent hover:text-primary transition-all duration-500 w-full sm:w-auto text-center leading-none">
                <PhoneCall size={22} />
                <span>Plan intakegesprek</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="mt-48 px-6 text-center">
        <div className="max-w-5xl mx-auto space-y-12 bg-white/50 backdrop-blur-md p-20 md:p-32 rounded-[5rem] border border-white shadow-2xl relative overflow-hidden group">
          <h2 className="text-6xl lg:text-[7rem] font-serif font-extrabold text-primary relative z-10 leading-none tracking-tighter italic">Klaar voor de start?</h2>
          <div className="pt-10 flex flex-col sm:flex-row justify-center gap-10 relative z-10 items-center">
            <Link to="/contact" className="glisten-btn group relative bg-accent text-primary px-14 py-8 rounded-full font-black tracking-widest uppercase text-sm inline-flex items-center justify-center gap-5 hover:bg-primary hover:text-white transition-all duration-500 shadow-2xl w-full sm:w-auto text-center leading-none">
              <span>Gratis Intake</span>
              <ArrowRight size={24} className="group-hover:translate-x-2 transition-transform" />
            </Link>
            <Link to="/diensten" className="glisten-btn group border-2 border-accent text-accent px-14 py-8 rounded-full font-black tracking-widest uppercase text-sm inline-flex items-center justify-center gap-5 hover:bg-accent hover:text-primary transition-all duration-500 w-full sm:w-auto text-center leading-none">
              <Compass size={24} />
              <span>Bekijk Pakketten</span>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
