
import React from 'react';
import { getSteps } from '../constants';
import { useLanguage } from '../context/LanguageContext';
import { Link } from 'react-router-dom';
import { CheckCircle, ArrowRight, Sparkles, Zap, BrainCircuit, Cpu } from 'lucide-react';

const Workflow: React.FC = () => {
  const { t, language } = useLanguage();
  const steps = getSteps(language);

  // Extra insights per stap om de "Slim gebouwd" positionering te versterken
  const smartInsights = [
    "AI-geoptimaliseerde doelgroepanalyse.",
    "Slimme layout-voorspellingen voor maximale conversie.",
    "Geautomatiseerde code-audit voor 100% snelheid.",
    "Dynamische SEO-activatie bij livegang."
  ];

  return (
    <div className="pb-32 bg-sand">
      {/* Dynamic Hero Header */}
      <section className="relative pt-48 pb-32 lg:pt-64 lg:pb-48 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-primary z-0">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1635776062127-d379bfcba9f8?auto=format&fit=crop&q=80&w=2000')] bg-cover opacity-10 mix-blend-overlay"></div>
          <div className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-t from-sand to-transparent"></div>
        </div>
        
        <div className="max-w-7xl mx-auto relative z-10 text-center lg:text-left flex flex-col lg:flex-row items-center justify-between gap-16">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-3 bg-accent/20 backdrop-blur-md px-5 py-2 rounded-full border border-accent/20 mb-8 animate-in fade-in slide-in-from-top duration-700">
              <Zap size={14} className="text-accent animate-pulse" />
              <span className="text-accent font-black uppercase tracking-[0.4em] text-[10px]">{t('workflow.badge')}</span>
            </div>
            <h1 className="text-6xl md:text-8xl lg:text-[10rem] font-serif font-extrabold text-white lg:text-primary mb-8 leading-[0.85] tracking-tighter italic animate-in fade-in slide-in-from-left duration-700 delay-100">
              Onze <br />
              <span className="text-accent">Werkwijze.</span>
            </h1>
          </div>
          <div className="lg:w-1/3 bg-white/50 backdrop-blur-xl p-10 rounded-[3rem] border border-white shadow-2xl animate-in fade-in slide-in-from-right duration-700 delay-200">
            <p className="text-xl text-gray-700 font-bold italic leading-relaxed">
              "{t('workflow.desc')}"
            </p>
          </div>
        </div>
      </section>

      {/* Modern Steps Section */}
      <section className="max-w-7xl mx-auto px-6 relative">
        {/* Connection Line */}
        <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-accent/0 via-accent/30 to-accent/0 hidden lg:block -translate-x-1/2 rounded-full">
          <div className="sticky top-1/2 w-full h-32 bg-accent blur-xl opacity-20 animate-pulse"></div>
        </div>
        
        <div className="space-y-40 lg:space-y-64">
          {steps.map((step, idx) => {
            const isEven = idx % 2 === 0;
            return (
              <div key={idx} className="relative z-10">
                <div className={`flex flex-col lg:flex-row items-center gap-16 lg:gap-32 ${isEven ? 'lg:flex-row-reverse' : ''}`}>
                  
                  {/* Text Content */}
                  <div className="lg:w-1/2 w-full">
                    <div className="group relative">
                      {/* Floating Number (Outline style) */}
                      <div className={`absolute -top-24 ${isEven ? '-right-4 lg:-right-12' : '-left-4 lg:-left-12'} text-[12rem] lg:text-[18rem] font-serif font-black text-transparent stroke-accent opacity-5 pointer-events-none select-none`} 
                           style={{ WebkitTextStroke: '2px var(--color-accent)' }}>
                        0{idx + 1}
                      </div>

                      <div className="bg-white p-12 lg:p-20 rounded-[4rem] shadow-premium hover:shadow-premium-hover border border-gray-100/50 relative overflow-hidden transition-all duration-700 hover:-translate-y-2">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-accent/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl group-hover:bg-accent/10 transition-colors"></div>
                        
                        <div className="flex items-center gap-6 mb-10">
                          <div className="w-20 h-20 bg-primary text-accent rounded-3xl flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform duration-500">
                            {step.icon}
                          </div>
                          <div className="h-px flex-grow bg-gray-100"></div>
                        </div>

                        <h3 className="text-4xl lg:text-5xl font-serif font-extrabold text-primary mb-8 tracking-tighter italic">
                          {step.title}
                        </h3>
                        <p className="text-xl text-gray-500 leading-relaxed font-medium mb-10">
                          {step.description}
                        </p>

                        {/* AI Insight Badge */}
                        <div className="inline-flex items-center gap-3 bg-sand border border-gray-100 px-6 py-3 rounded-2xl group-hover:border-accent/20 transition-colors">
                          <BrainCircuit size={18} className="text-accent" />
                          <span className="text-[10px] font-black uppercase tracking-widest text-primary opacity-70">
                            {smartInsights[idx]}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Visual Center Point (Desktop) */}
                  <div className="hidden lg:flex w-16 h-16 bg-white rounded-full items-center justify-center text-accent z-20 border-8 border-sand absolute left-1/2 -translate-x-1/2 shadow-2xl overflow-hidden group/dot">
                    <div className="w-4 h-4 bg-accent rounded-full animate-pulse"></div>
                    <div className="absolute inset-0 bg-accent scale-0 group-hover/dot:scale-100 transition-transform duration-500 rounded-full flex items-center justify-center">
                      <Cpu size={24} className="text-primary animate-spin-slow" />
                    </div>
                  </div>

                  {/* Image Content */}
                  <div className="lg:w-1/2 w-full">
                    <div className="relative group">
                      <div className="absolute inset-0 bg-accent/20 blur-[100px] rounded-full opacity-0 group-hover:opacity-40 transition-opacity duration-1000"></div>
                      <div className="rounded-[4rem] overflow-hidden shadow-2xl aspect-[1.1] w-full relative border-8 border-white bg-white group-hover:rotate-1 transition-all duration-700">
                        <img 
                          src={step.image} 
                          alt={step.title} 
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[8000ms] ease-out" 
                          loading="lazy" 
                        />
                        <div className="absolute inset-0 bg-primary/30 opacity-0 group-hover:opacity-100 transition-opacity duration-700 flex items-center justify-center backdrop-blur-[2px]">
                           <div className="bg-white/90 backdrop-blur-md px-10 py-6 rounded-3xl transform translate-y-10 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-700 shadow-2xl">
                              <span className="text-primary font-black uppercase tracking-[0.4em] text-[10px]">Gefocusseerd op Resultaat</span>
                           </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Monumental Summary Card */}
      <section className="mt-64 max-w-7xl mx-auto px-6">
        <div className="bg-primary text-white rounded-[5rem] p-12 lg:p-32 border border-white/10 shadow-[0_80px_160px_rgba(0,0,0,0.4)] overflow-hidden relative group">
          <div className="absolute top-0 right-0 w-2/3 h-full bg-accent/5 blur-[150px] rounded-full translate-x-1/3 -translate-y-1/3 group-hover:scale-150 transition-transform duration-1000"></div>
          
          <div className="grid lg:grid-cols-12 gap-20 lg:gap-32 items-center relative z-10">
            <div className="lg:col-span-5 hidden lg:block">
              <div className="relative">
                <div className="absolute -inset-4 bg-accent/20 blur-3xl rounded-full opacity-50 group-hover:opacity-80 transition-opacity"></div>
                <div className="rounded-[4.5rem] overflow-hidden shadow-2xl border-8 border-white/10 aspect-[3/4] -rotate-3 group-hover:rotate-0 transition-transform duration-1000">
                  <img 
                    src="https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80&w=1000" 
                    alt="Samenwerking aan resultaat" 
                    className="w-full h-full object-cover" 
                  />
                </div>
              </div>
            </div>
            
            <div className="lg:col-span-7 space-y-16">
              <div className="space-y-8 text-center lg:text-left">
                <span className="text-accent font-black uppercase tracking-[0.6em] text-[10px] block mb-2">{t('workflow.impact')}</span>
                <h2 className="text-6xl md:text-8xl lg:text-[9rem] font-serif font-extrabold leading-[0.85] tracking-tighter italic">
                  Direct <br />
                  <span className="text-accent">Impact.</span>
                </h2>
                <p className="text-2xl md:text-3xl text-gray-400 font-bold leading-relaxed italic border-l-4 border-accent pl-10 max-w-2xl">
                  {t('workflow.impact.desc')}
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-8 items-center justify-center lg:justify-start pt-10">
                <Link to="/contact" className="glisten-btn group relative bg-accent text-primary px-16 py-8 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center gap-5 hover:bg-white transition-all duration-500 shadow-2xl w-full sm:w-auto justify-center">
                  <span className="relative z-10">{t('hero.cta.start')}</span>
                  <ArrowRight size={22} className="relative z-10 group-hover:translate-x-3 transition-transform duration-500" />
                </Link>
                <Link to="/diensten" className="glisten-btn group border-2 border-accent text-accent px-16 py-8 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center gap-5 hover:bg-accent hover:text-primary transition-all duration-500 shadow-xl w-full sm:w-auto justify-center">
                  <Sparkles size={22} className="group-hover:rotate-12 transition-transform duration-500" />
                  <span>{t('hero.cta.packages')}</span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Quote Section */}
      <section className="mt-48 text-center px-6">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="h-px w-24 bg-accent/30 mx-auto"></div>
          <p className="text-3xl md:text-5xl font-serif font-black text-primary italic leading-tight tracking-tight">
            "Bij Broekstra geloven we dat een website niet alleen functioneel moet zijn, maar een beleving moet creëren."
          </p>
          <div className="h-px w-24 bg-accent/30 mx-auto"></div>
        </div>
      </section>
    </div>
  );
};

export default Workflow;
