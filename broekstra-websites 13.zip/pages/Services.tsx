
import React from 'react';
import { useDynamicData } from '../context/DynamicDataContext';
import { useLanguage } from '../context/LanguageContext';
import * as Icons from 'lucide-react';
import { Link } from 'react-router-dom';
import { CheckCircle2, ArrowRight, PhoneCall, HelpCircle, ChevronRight, LifeBuoy, Sparkles as SparklesIcon } from 'lucide-react';

const Services: React.FC = () => {
  const { t } = useLanguage();
  const { services } = useDynamicData();

  return (
    <div className="pb-32">
      {/* Header - Image removed, solid primary blue remains */}
      <section className="bg-primary text-white pt-48 pb-32 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-primary z-0"></div>
        <div className="absolute top-0 right-0 w-1/3 h-full bg-accent/10 blur-[100px] rounded-full translate-x-1/2 -translate-y-1/2"></div>
        <div className="max-w-7xl mx-auto text-left relative z-10">
          <h1 className="text-6xl lg:text-9xl font-serif font-extrabold mb-8 leading-none italic">{t('services.title')}</h1>
          <p className="text-2xl text-gray-300 max-w-2xl font-extrabold uppercase tracking-tight">
            Transparante prijzen. <span className="text-accent italic">Luxe resultaten.</span>
          </p>
        </div>
      </section>

      {/* Service Blocks */}
      <section className="max-w-7xl mx-auto px-6 mt-32 space-y-48">
        {services.map((service, idx) => {
          const IconComponent = (Icons as any)[service.icon];
          const isEven = idx % 2 === 0;
          const isCustom = service.id === 'custom' || service.price === '—';

          return (
            <div key={service.id} className={`flex flex-col ${isEven ? 'lg:flex-row' : 'lg:flex-row-reverse'} gap-16 lg:gap-24 items-center`}>
              <div className="lg:w-7/12 space-y-10">
                <div className="flex items-start gap-8">
                  <div className={`w-20 h-20 ${isCustom ? 'bg-primary text-accent' : 'bg-accent text-primary'} rounded-[2rem] flex items-center justify-center shadow-2xl shadow-accent/20 shrink-0`}>
                    <IconComponent size={36} />
                  </div>
                  <div>
                    <h2 className="text-5xl font-serif font-extrabold text-primary mb-2 leading-none">{service.title}</h2>
                    <div className="flex flex-col pt-4">
                       {service.originalPrice && (
                         <span className="text-gray-400 font-bold line-through text-xl mb-1">€{service.originalPrice}</span>
                       )}
                       <div className="flex items-baseline gap-4">
                          <div className="text-accent font-black text-6xl tracking-tighter">
                            € {service.price}
                          </div>
                          <span className="text-gray-400 font-black uppercase tracking-widest text-[10px]">
                            {isCustom ? 'Prijs op aanvraag' : t('hero.price.excl')}
                          </span>
                       </div>
                    </div>
                  </div>
                </div>
                
                <p className="text-2xl text-gray-600 leading-relaxed font-bold italic">"{service.longDescription}"</p>
                
                <div className="bg-white p-12 rounded-[3rem] shadow-sm border border-gray-100 relative overflow-hidden">
                  <div className={`absolute top-0 left-0 w-2 h-full ${isCustom ? 'bg-primary' : 'bg-accent'}`}></div>
                  <h4 className="font-black text-primary uppercase tracking-[0.3em] text-[10px] mb-8 block">{t('services.included')}</h4>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {service.benefits.map((benefit, bIdx) => (
                      <li key={bIdx} className="flex items-center gap-4 text-gray-800 font-extrabold">
                        <CheckCircle2 size={24} className="text-accent shrink-0" />
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="pt-8 flex flex-col sm:flex-row gap-6">
                  <Link 
                    to={`/diensten/${service.id}`} 
                    className="glisten-btn group relative bg-accent text-primary px-10 py-6 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center gap-4 hover:bg-primary hover:text-white transition-all duration-500 shadow-2xl"
                  >
                    <span>{t('services.view')}</span>
                    <ChevronRight size={20} className="group-hover:translate-x-2 transition-transform duration-500" />
                  </Link>

                  <Link 
                    to="/contact" 
                    className="glisten-btn group border-2 border-accent text-accent px-10 py-6 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center gap-4 hover:bg-accent hover:text-primary transition-all duration-500"
                  >
                    <HelpCircle size={20} className="group-hover:rotate-12 transition-transform duration-500" />
                    <span>{t('services.ask')}</span>
                  </Link>
                </div>
              </div>
              
              <div className="lg:w-5/12 relative group w-full max-w-lg lg:max-w-none">
                <div className="aspect-square bg-sand rounded-[3.5rem] overflow-hidden shadow-2xl border-8 border-white">
                  <img 
                    src={service.image} 
                    alt={service.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[2000ms]"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
                  
                  {service.originalPrice && (
                    <div className="absolute top-8 left-8 bg-accent text-primary px-6 py-2 rounded-full font-black text-[10px] uppercase tracking-widest shadow-xl animate-bounce">
                       Tijdelijke korting
                    </div>
                  )}
                </div>
                <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-accent/20 rounded-full blur-[80px] -z-10 animate-pulse"></div>
              </div>
            </div>
          );
        })}
      </section>

      {/* Final CTA Section */}
      <section className="mt-40 px-6">
        <div className="max-w-5xl mx-auto bg-primary text-white rounded-[4rem] p-16 lg:p-32 text-center relative overflow-hidden group">
          <div className="absolute inset-0 bg-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
          <h2 className="text-5xl lg:text-[7rem] font-serif font-extrabold mb-10 relative z-10 leading-none tracking-tighter italic">Klaar voor impact?</h2>
          <p className="text-2xl text-gray-400 mb-16 max-w-2xl mx-auto relative z-10 font-extrabold uppercase tracking-tight">
            Ontdek welk pakket het beste aansluit bij uw groeiambities of vraag een custom offerte aan.
          </p>
          <div className="flex flex-col sm:flex-row gap-8 justify-center relative z-10 items-center">
            <Link 
              to="/contact" 
              className="glisten-btn group relative bg-accent text-primary px-12 py-6 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center gap-4 hover:bg-white hover:text-primary transition-all duration-500 shadow-2xl"
            >
              <span>{t('services.cta.contact')}</span>
              <ArrowRight size={22} className="group-hover:translate-x-2 transition-transform duration-500" />
            </Link>
            
            <a 
              href="tel:+31636071498" 
              className="glisten-btn group border-2 border-accent text-accent px-12 py-6 rounded-full font-black tracking-widest uppercase text-xs inline-flex items-center gap-4 hover:bg-accent hover:text-primary transition-all duration-500 shadow-xl"
            >
              <PhoneCall size={22} className="group-hover:rotate-12 transition-transform duration-500" />
              <span>{t('services.cta.call')}</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;
